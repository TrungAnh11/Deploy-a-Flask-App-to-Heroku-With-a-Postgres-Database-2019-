from django.contrib import admin
from .models import Language

admin.site.register(Language)
