from django.apps import AppConfig


class UserExampleConfig(AppConfig):
    name = 'user_example'
