$(document).ready(function() {

  /*
  $(".clicky").on('click', function() {
    alert("Clicked!");
  });
*/

  $(document).on('click', '.clicky', function() {
    alert("New Click!");
  })

});
