from django.contrib import admin
from .models import Programmer, Language

admin.site.register(Programmer)
admin.site.register(Language)