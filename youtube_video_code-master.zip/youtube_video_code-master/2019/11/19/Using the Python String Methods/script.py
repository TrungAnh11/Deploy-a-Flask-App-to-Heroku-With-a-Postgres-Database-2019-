mystr = 'The Quick BROWN fox jumps over the lazy dog.'

#print(mystr.capitalize())
#print(mystr.lower())
#print(mystr.upper())
#print(mystr.swapcase())
#print(mystr.title())

#print(mystr.count('O'))
#print(mystr.endswith('dog'))
#print(mystr.startswith('The'))
#print(mystr.find('cat'))
#print(mystr.rfind('he'))
#print(mystr.index('cat'))

#print('123AC'.isalnum())
#print('abcABC'.isalpha())
#print('abcABC'.isascii())
#isdecimal, isdigit, islower, isnumeric, isspace, istitle, isupper

#print(mystr.center(100))
#print(mystr.ljust(100, '-'))
#print(mystr.rjust(100, '-'))

#mystr = '      The Quick BROWN fox jumps over the lazy dog.           '
#print(mystr.strip())

#print(mystr.partition('he'))
#print(mystr.rpartition('he'))
#print(mystr.split('he'))

text = '''Anthony created Pretty Printed in
the year 2015.'''

print(text.splitlines())