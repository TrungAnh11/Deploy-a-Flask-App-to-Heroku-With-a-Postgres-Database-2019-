name = 'Anthony'
favorite_language = 'Python'

#print(f'Name: { name }')
#print(f'Favorite Language: { favorite_language }')
print(f'{name=}')
print(f'{favorite_language=}')