print('Hello World!')

#print(5 * 10)

#name = 'Pretty Printed'

name = input('Enter your name: ')

print(name)

x = input('Enter the first number: ')
y = input('Enter the second number: ')

#print(int(x) * int(y))
z = int(x) * int(y)
print(f'The result of { x } * { y } = { z }')