from .extensions import db

class MyModel(db.Model):
    pass