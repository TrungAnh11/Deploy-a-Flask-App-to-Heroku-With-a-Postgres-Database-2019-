from flask_qa import create_app

app = create_app()