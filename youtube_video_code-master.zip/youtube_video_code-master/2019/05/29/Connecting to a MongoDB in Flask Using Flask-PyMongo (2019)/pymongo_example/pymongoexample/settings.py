import os

MONGO_URI = os.environ.get('MONGO_URI')